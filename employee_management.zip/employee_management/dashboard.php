<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Employee Dashboard</title>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
    <ul>
        <li><a href="mark_attendance.php">Mark Attendance</a></li>
        <li><a href="apply_leave.php">Apply for Leave</a></li>
        <li><a href="leave_status.php">View Leave Status</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
