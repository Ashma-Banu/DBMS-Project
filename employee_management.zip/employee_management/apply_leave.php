<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Apply for Leave</title>
</head>
<body>
    <h2>Apply for Leave</h2>
    <form method="post" action="process_leave.php">
        Start Date: <input type="date" name="start_date" required><br><br>
        End Date: <input type="date" name="end_date" required><br><br>
        Reason:<br>
        <textarea name="reason" rows="4" cols="50" required></textarea><br><br>
        <button type="submit">Submit Leave Request</button>
    </form>
    <br>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
