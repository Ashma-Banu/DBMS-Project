<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Register - Employee Management</title>
</head>
<body>
    <h2>Employee Registration</h2>
    <form method="post" action="process_register.php">
        Name: <input type="text" name="name" required><br><br>
        Username: <input type="text" name="username" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <button type="submit">Register</button>
    </form>
    <br>
    <a href="index.php">Already have an account? Login here</a>
</body>
</html>
