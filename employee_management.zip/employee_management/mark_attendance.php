<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'employee') {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Mark Attendance</title>
</head>
<body>
    <h2>Mark Attendance for <?php echo date('Y-m-d'); ?></h2>
    <form method="post" action="process_attendance.php">
        Forenoon: 
        <select name="forenoon" required>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
        </select><br><br>
        Afternoon: 
        <select name="afternoon" required>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
        </select><br><br>
        <button type="submit">Submit Attendance</button>
    </form>
    <br>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
