<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        #employeeFields, #adminFields {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Login</h2>

    <label for="role">Select Role:</label>
    <select id="role" onchange="toggleFields()">
        <option value="admin">Admin</option>
        <option value="employee">Employee</option>
    </select>

    <div id="adminFields">
        <input type="text" id="adminUsername" placeholder="Admin Username">
        <input type="password" id="adminPassword" placeholder="Admin Password">
    </div>

    <div id="employeeFields" style="display:none;">
        <input type="text" id="empIdLogin" placeholder="Employee ID">
    </div>

    <button onclick="handleLogin()">Login</button>
</div>

<script>
    function toggleFields() {
        const role = document.getElementById("role").value;
        document.getElementById("adminFields").style.display = role === "admin" ? "block" : "none";
        document.getElementById("employeeFields").style.display = role === "employee" ? "block" : "none";
    }

    function handleLogin() {
        const role = document.getElementById("role").value;

        if (role === "admin") {
            const username = document.getElementById("adminUsername").value;
            const password = document.getElementById("adminPassword").value;

            if (username === "admin" && password === "admin123") {
                location.href = "admin_attendance.html"; // Admin still gets redirected
            } else {
                alert("Invalid Admin credentials.");
            }

        } else if (role === "employee") {
            const empId = document.getElementById("empIdLogin").value;

            if (empId.trim() !== "") {
    alert("Employee login successful!");
    location.href = "leave_request.html";  // Redirect to leave request form
} else {
    alert("Please enter Employee ID.");
}
        }
    }
</script>
</body>
</html>
