<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'manager') {
    header("Location: index.php");
    exit();
}

$today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manager Dashboard</title>
</head>
<body>
    <h1>Welcome Manager, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>

    <h2>Daily Attendance Report for <?php echo $today; ?></h2>
    <?php
    $sql = "SELECT e.name, a.forenoon, a.afternoon FROM attendance a JOIN employees e ON a.employee_id = e.id WHERE a.date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $today);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>Employee</th>
            <th>Forenoon</th>
            <th>Afternoon</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['forenoon']); ?></td>
                <td><?php echo htmlspecialchars($row['afternoon']); ?></td>
            </tr>
        <?php } ?>
    </table>

    <h2>Pending Leave Requests</h2>
    <?php
    $sql2 = "SELECT l.id, e.name, l.start_date, l.end_date, l.reason FROM leave_requests l JOIN employees e ON l.employee_id = e.id WHERE l.status='pending'";
    $result2 = $conn->query($sql2);
    ?>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>Employee</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Reason</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result2->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                <td><?php echo htmlspecialchars($row['reason']); ?></td>
                <td>
                    <form method="post" action="process_leave_approval.php" style="display:inline;">
                        <input type="hidden" name="leave_id" value="<?php echo $row['id']; ?>">
                        <button name="action" value="approved">Approve</button>
                        <button name="action" value="rejected">Reject</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

    <br>
    <a href="logout.php">Logout</a>
</body>
</html>
